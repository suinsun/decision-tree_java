Use Front.java (in decisiontree) to begin the whole project.
In this project, you can use 1-13 to select the data that you want to train, 
and use 1(prune) or 0(not prune) to decide if you want to exam prune.
The result will show the builded tree and some information about it. 
And it also shows the accuracy of test set.
{You can see the classify result if cancel annotation in TestTree.java-toString()}