package treeStructure;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import dataset.DSet;
import treeStructure.DTgenerate.Result;

public class DTree {
	DTnode root;
	static int depth=0;
	private int curDepth = 0;
	static int numNode;
	int numLeaf;
	boolean prun;
	DTgenerate ea=new DTgenerate();
	public DTree(DTnode node){
		root=node;
	}
	public DTnode getRoot(){
		return root;
	}
	public DTree(){}
	public DTree genTree(DSet data){
		ea.genFValue(data);
		
		numNode=1;
		DTnode roo;
		DTree tree;
		double info=ea.InfoGain(data);
		ArrayList<Result> infoF=ea.InfoGainF(data);
		double min=infoF.get(0).getInfo();
		int minP=0;
		for(int i=0;i<infoF.size();i++){
			if(infoF.get(i).getInfo()<min){
				min=infoF.get(i).getInfo();
				minP=i;
			}
			else
				continue;
		}
		double InfoGain=info-min;
		roo=new DTnode();
		double maxc=getMaxClass(data);
		roo.setMaxClassValue(maxc);
		roo.setInfo(InfoGain);
		roo.setPoint(infoF.get(minP).getSplit());
		roo.setSplitName(infoF.get(minP).getSplitName());
		roo.setAttrName(infoF.get(minP).getSplitName());
		roo.setAttrValue(infoF.get(minP).getSplit());
		roo.setDepth(curDepth);
		if(checkSet(data)){
			curDepth++;
			if(curDepth>depth){depth=curDepth;}
			DSet left=splitSetL(data,roo.getAttrName(),roo.getPoint());
			DSet right=splitSetR(data,roo.getAttrName(),roo.getPoint());
			DTnode LND=genNode(left);
			DTnode RND=genNode(right);
			roo.setChild(LND);
			LND.setParent(roo);
			LND.setAttrValue(infoF.get(minP).getSplit());
			LND.setAttrName(infoF.get(minP).getSplitName());
			LND.setStatus(-1);
			LND.setDepth(curDepth);
			roo.setChild(RND);
			RND.setParent(roo);
			RND.setAttrValue(infoF.get(minP).getSplit());
			RND.setAttrName(infoF.get(minP).getSplitName());
			RND.setStatus(1);
			RND.setDepth(curDepth);
			curDepth--;
		}
		tree=new DTree(roo);
		return tree;
		
	}
	
	
	
	
	public DTnode genNode(DSet dataset){
		
		numNode++;
		DTnode newNode;
		double info=ea.InfoGain(dataset);
		ArrayList<Result> list=ea.InfoGainF(dataset);
		
		double min=list.get(0).getInfo();
		int minP=0;
		
		for(int i=0;i<list.size();i++){
			if(list.get(i).getInfo()<min){
				min=list.get(i).getInfo();
				minP=i;
			}
			else
				continue;
		}
		double InfoGain=info-min;
		newNode=new DTnode();
		double maxc=getMaxClass(dataset);
		newNode.setMaxClassValue(maxc);
		newNode.setInfo(InfoGain);
		newNode.setPoint(list.get(minP).getSplit());
		newNode.setSplitName(list.get(minP).getSplitName());
		if(checkSet(dataset)){
			curDepth++;
			if(curDepth>depth){depth=curDepth;}
			int depth = newNode.depth + 1;
			DSet left=splitSetL(dataset,newNode.getSplitName(),newNode.getPoint());
			DSet right=splitSetR(dataset,newNode.getSplitName(),newNode.getPoint());
			//System.out.println("begin a node");
			if(!left.dataset.isEmpty()){
				DTnode LND=genNode(left);
				newNode.setChild(LND);
				LND.setParent(newNode);
				LND.setAttrName(list.get(minP).getSplitName());
				LND.setAttrValue(list.get(minP).getSplit());
				//System.out.println(LND.depth);
			    LND.setStatus(-1);
			    LND.setDepth(curDepth);
			    newNode.hasClass=false;
			    if(depth < curDepth) depth = curDepth;
			}
			if(!right.dataset.isEmpty()){
				DTnode RLD=genNode(right);
				newNode.setChild(RLD);
				RLD.setParent(newNode);
				RLD.setAttrName(list.get(minP).getSplitName());
				RLD.setAttrValue(list.get(minP).getSplit());
				//System.out.println(RLD.depth);
				RLD.setStatus(1);
				RLD.setDepth(curDepth);
				newNode.hasClass=false;
				if(depth < curDepth) depth = curDepth;
			}
			curDepth--;
			
		}
		else{
			newNode.hasClass=true;
			newNode.ClassValue=dataset.dataset.get(0).getElement(0).GetClass();
		}
		//System.out.println("Build the tree successfully");
		
		return newNode;
		
		
	}
	public boolean checkSet(DSet dataset){
		boolean result=false;
		int size=dataset.dataset.size();
		int length=dataset.dataset.get(0).getElement().length;
		double check=dataset.dataset.get(0).getElement(length-1).GetClass();
		for(int i=0;i<size;i++){
			double newcheck=dataset.dataset.get(i).getElement(length-1).GetClass();
			if(newcheck!=check)
				result=true;
			else
				continue;
		}
		return result;
		
	}
	public DSet splitSetL(DSet dataset, int attr, double point){
		DSet leftSet=new DSet();
		int size=dataset.dataset.size();
		for(int i=0;i<size;i++){
			if(dataset.dataset.get(i).getElement(attr).GetValue()<=point){
				leftSet.dataset.add(dataset.dataset.get(i));
			}
		}
		return leftSet;
	}
	public double getMaxClass(DSet data){
		int size=data.dataset.size();
		int length=data.dataset.get(0).getElement().length;
		Map<Double, Integer> k=new HashMap<Double, Integer>();
		for(int i=0;i<size;i++){
		double key=data.dataset.get(i).getElement(length-1).GetClass();
		//System.out.println(key);
		if(k.containsKey(key)){
			int value=(int) k.get(key)+1;
			k.put(key,value);
		}
		else{
			k.put(key, 1);
		}
		}
		int max=0;
		double maxclass=-1;
		for(double key:k.keySet()){
			if(k.get(key)>max){
				max=k.get(key);
				maxclass=key;}
		}
		return maxclass;
		
	}
	public int getTreeDepth(DTnode node){
		int curD = 0;
		int lD = 0;
		int rD = 0;

		if (!node.getHasClass()) {
		lD = getTreeDepth(node.getChild(-1));
		rD = getTreeDepth(node.getChild(1));
		curD = lD > rD ? lD : rD;
		return (curD + 1);
		}else{
		return 0;
		}
	}
	public void setDepth(int d){
		DTree.depth=d;
	}
	static int c=0;
	public void getTreeNode(DTnode node){
		if(!node.getHasClass()){
			getTreeNode(node.getChild(-1));
			getTreeNode(node.getChild(1));
			c++;
		}
		else{c++;}
		 
	}
	public int returnC(){
		DTree.numNode=c;
		return DTree.c;
	}
	public String toString(){
		String result="";
		result+="------------Tree Structure------------------\n";
		result+=root.toString();
		result+="------------Tree Information----------------\n";
		result+="The number of nodes is:  "+DTree.numNode+"\n";
		result+="The number of level is:  "+DTree.depth+"\n";
		return result;
		
	}
	public DSet splitSetR(DSet dataset, int attr, double point){
		DSet rightSet=new DSet();
		int size=dataset.dataset.size();
		for(int i=0;i<size;i++){
			if(dataset.dataset.get(i).getElement(attr).GetValue()>point){
				rightSet.dataset.add(dataset.dataset.get(i));
			}
		}
		return rightSet;
	}
	
	

}
