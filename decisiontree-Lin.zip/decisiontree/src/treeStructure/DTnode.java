package treeStructure;

import java.util.*;

import dataset.DElement;

public class DTnode {

	int attrName;
	double attrValue;
	int splitName;
	double splitPoint;
	double infoGain;
	int depth;
	boolean hasClass;
	double ClassValue;
	double maxClassValue;
	ArrayList<DTnode> children=new ArrayList<DTnode>();
	

	DTnode parent;
	ArrayList<DElement> subset=new ArrayList<DElement>();
	int status=0;
	public DTnode(){
		
	}
	public void setAttrName(int aName){
		this.attrName=aName;
	}
	public void setInfo(double info){
		this.infoGain=info;
	}
	public void setPoint(double sPoint){
		this.splitPoint=sPoint;
	}
	public void setSplitName(int i){
		this.splitName=i;
	}
	public int getSplitName(){
		return this.splitName;
	}
	public void setAttrValue(double i){
		this.attrValue=i;
	}
	public double getAttrValue(){
		return this.attrValue;
	}
	public void setMaxClassValue(double i){
		this.maxClassValue=i;
	}
	public double getMaxClassValue(){
		return this.maxClassValue;
	}
	public void setChild(DTnode c){
		this.children.add(c);
	}
	public void setSubset(DElement em){
		this.subset.add(em);
	}
	public void setSubset(ArrayList<DElement> em){
		for(int i=0;i<em.size();i++){
			this.subset.add(em.get(i));
		}

	}
	public ArrayList<DElement> getSubset(){
		return this.subset;
	}
	public DTnode getChild(int status){
		DTnode result=new DTnode();
			for(DTnode child:children){
				if(status==child.getStatus()){
					result= child;
				}
			}
		return result;
	}

	public void deleteLChild(DTnode c){
		this.children.remove(c);
	}
	
	public int getAttrName(){
		return this.attrName;
	}
	public double getPoint(){
		return this.splitPoint;
	}
	public void setDepth(int d){
		this.depth=d;
	}
	public int getDepth(){
		return this.depth;
	}
	public void setHasClass(boolean b){
		this.hasClass=b;
	}
	public boolean getHasClass(){
		return this.hasClass;
	}
	public void setClassValue(double d){
		this.ClassValue=d;
	}
	public double getClassValue(){
		return this.ClassValue;
	}
	public void setParent(DTnode p){
		this.parent=p;
	}
	public void setStatus(int i){
		this.status=i;
	}
	public int getStatus(){
		return this.status;
	}
	public String toString(){
		String res="";
		for(int i=0;i<depth;i++) res+= "| ";
		res+="["+status+"]";
		res+="(Attribute"+this.attrName;
		if(depth!=0){
			if(status==-1){res+="<=";}
			else {res+=">";}
			res+=this.attrValue;
		}
		res+="):";
		if(this.hasClass==true){
			res+="[Class Value:"+this.ClassValue+"]";
		}
		res+="\n";
		if(!this.children.isEmpty()){
			for(DTnode child:children) res+=child.toString();
		}
		
		return res;
	}
	
	

}
