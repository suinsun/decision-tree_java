package treeStructure;
import java.util.*;
import dataset.DSet;



public class DTgenerate {
	@SuppressWarnings("rawtypes")
	ArrayList<ArrayList> sumlist=new ArrayList<ArrayList>();
	public double InfoGain(DSet ds){
		double info = 0;
		//compute original Info
		double size=ds.dataset.size();
		//System.out.println(size);
		if(size>0){
			int length=ds.dataset.get(0).getElement().length;
			//System.out.println(length);
			Map<Double, Integer> k=new HashMap<Double, Integer>();
			for(int i=0;i<size;i++){
			double key=ds.dataset.get(i).getElement(length-1).GetClass();
			//System.out.println(key);
			if(k.containsKey(key)){
				int value=(int) k.get(key)+1;
				k.put(key,value);
			}
			else{
				k.put(key, 1);
			}
			}
			//System.out.println(k.size());
			for(double key:k.keySet()){
				//System.out.println(key);
				double d=(k.get(key))/size;
				info+=-1*d*Math.log(d)/Math.log(2);
				//System.out.println(key+"-----"+k.get(key));
			}
		}
		return info;
	}
	
	public ArrayList<Result> InfoGainF(DSet da){
		ArrayList<Result> result=new ArrayList<Result>();
		
		//compute feature infoGain
		if(da.dataset.size()>0){
			double size=da.dataset.size();
			int length=da.dataset.get(0).getElement().length;
			
			for(int i=0;i<length-1;i++){
				//System.out.println("Begin a new colum");
				
				for(int j=0;j<this.sumlist.get(i).size()-1;j++){
					//System.out.printf("the j is %d\n", j);
					double sPoint=(double) this.sumlist.get(i).get(j);
					//System.out.println(sPoint);
					
					//generate the sorted array of feature value
					
					//for each value, generate two subset
					DSet new1=new DSet();
					DSet new2=new DSet();
					for(int p=0;p<size;p++){
						if (da.dataset.get(p).getElement(i).GetValue()<=sPoint){
							new1.genNewSet(da.dataset.get(p).getElement(i));
						}
						else{
							new2.genNewSet(da.dataset.get(p).getElement(i));
						}
					}
					
					//compute infoGain for each subset
					double info1=this.InfoGain(new1);
					double info2=this.InfoGain(new2);
					double infox=(new1.dataset.size()/size)*info1+(new2.dataset.size()/size)*info2;
					Result r=new Result(infox,i,sPoint);
					result.add(r);
					
				}
			}
			
		}
		else{
			System.out.println("Invalid dataset");
		}
		return result;
		
	}//InfoGainF
	
	public void genFValue(DSet da){
		double size=da.dataset.size();
		int length=da.dataset.get(0).getElement().length;
		for(int i=0;i<length;i++){
			ArrayList<Double> list=new ArrayList<Double>();
			for(int j=0;j<size;j++){
				double FValue=da.dataset.get(j).getElement(i).GetValue();
				//System.out.println(FValue);
				if(list.contains(FValue)){
					continue;
				}
				else{list.add(FValue);}
				
			}
			Collections.sort(list);
//			for(double counter:list){
//				System.out.printf("%f  ",counter);
//			}
			this.sumlist.add(list);
			//System.out.println();
		}
		
//		for(int k=0;k<length;k++){
//			for(int m=0;m<sumlist.get(k).size();m++){
//				System.out.printf("%f  ", sumlist.get(k).get(m));
//				
//			}
//			System.out.println();
//			
//		}
		
	}//genFValue
	
	
	public class Result{
		double inforGain;
		
		int splitname;
		double spliPoint;
		public Result(double i,  int sn,double sp){
			this.inforGain=i;
			this.splitname=sn;
			this.spliPoint=sp;
		}
		public double getInfo(){
			return inforGain;
		}
		public int getSplitName(){
			return splitname;
		}
		public double getSplit(){
			return spliPoint;
		}
	}
	
	

}
