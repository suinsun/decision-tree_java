package dataset;

public class DElement {
	DAttr[] attr;
	String[] Sname;
	DAttr singleAttr;
	

	public DElement(String line){
		
		String[] Svalue=line.split(",");
		//this.Sname=nameLine.split(",");
		int number=Svalue.length;
		//System.out.println(number);
		attr=new DAttr[number];
		for(int i=0;i<number-1;i++){
			double term=Double.parseDouble(Svalue[i]);
			double classV=Double.parseDouble(Svalue[number-1]);
			//System.out.printf("%f  %f  \n",term,classV);
			attr[i]=new DAttr(i+1,term,classV);
			
			
		}
		attr[number-1]=new DAttr(number,Double.parseDouble(Svalue[number-1]),Double.parseDouble(Svalue[number-1]));
		
	}
	public DElement(DAttr da) {
		// TODO Auto-generated constructor stub
		attr=new DAttr[1];
		this.attr[0]=da;
	}
	//get element
	public DAttr[] getElement(){
		return attr;
	}
	public DAttr getElement(int i){
		return attr[i];
	}

	
	
	
	//get attribute
	public DAttr getAttr(String name){
		for(int i=0;i<this.Sname.length;i++){
			if(Sname[i].compareTo(name)==0){
				return attr[i];
			}
			else continue;
		}
		return null;

	}

}
