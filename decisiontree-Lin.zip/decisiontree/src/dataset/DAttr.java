package dataset;

public class DAttr {
	int attrName;
	double attrValue;
	double classValue;

	public DAttr(int s, double term, double classV) {
		// TODO Auto-generated constructor stub
		this.attrName=s;
		this.attrValue=term;
		this.classValue=classV;
	}
	public DAttr(){}
	public int GetName(){
		return this.attrName;
	}
	public double GetValue(){
		return this.attrValue;
	}
	public double GetClass(){
		return this.classValue;
	}
	
    


	
	public String toString(){
		String res = "";
		
		res += "[";
		res += attrName + ":";
		res += attrValue + "--"+classValue+"]";
		return res;
	}
}
