package dataset;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;

public class DSet {
	public List<DElement> dataset=new ArrayList<DElement>();
	
	public void genNewSet(DAttr da){
		DElement de=new DElement(da);
		this.dataset.add(de);
		
	}
	
	public List<DElement> readFile(String file){
		
		try{
			FileReader fr=new FileReader(file);
			BufferedReader bufr=new BufferedReader(fr);
			//String attrName=bufr.readLine();
			String s=null;
			while ((s=bufr.readLine())!=null){
				//System.out.println(s);
				DElement datarow=new DElement(s);
				this.dataset.add(datarow);
			}
			bufr.close();
			fr.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return this.dataset;

	}
	//print all dataset
	public void printDataset(List<DElement> dataset){
		int numE=dataset.size();
		//System.out.println(numE);
		for(int i=0;i<numE;i++){
			DAttr[] tAttr=dataset.get(i).getElement();
			int numA=tAttr.length;
			for(int j=0;j<numA;j++){
				System.out.print(tAttr[j]);
				System.out.print("  ");
			}
			System.out.println();
		}
		
	}
	//

}




