package decisiontree;

import java.io.File;
import java.util.Scanner;

import dataset.*;
import treeStructure.*;

public class Front {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Please select the file you want to train:");
		System.out.println("1:yellow-small.data");
		System.out.println("2:adult+stretch.data");
		System.out.println("3:adult-stretch.data");
		System.out.println("4:yellow-small+adult-stretch.data");
		System.out.println("5:pen-2.csv");
		System.out.println("6:pen-3.csv");
		System.out.println("7:pen-10.csv");
		System.out.println("8:pen-20.csv");
		System.out.println("9:pen-30.csv");
		System.out.println("10:pen-40.csv");
		System.out.println("11:pen-50.csv");
		System.out.println("12:pen-60.csv");
		System.out.println("13:wbdc-train.data");
		String basefile=new File("").getAbsolutePath();
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		int input=sc.nextInt();
		String train_file="";
		String test_file="";
		String prune_file="";
		switch(input){
		case 1: train_file=basefile+"/file/yellow-small.data";
		        break;
		case 2:train_file=basefile+"/file/adult+stretch.data";
		       break;
		case 3:
			train_file=basefile+"/file/adult-stretch.data";
			break;
		case 4:
			train_file=basefile+"/file/yellow-small+adult-stretch.data";
			break;
		case 5:
			train_file=basefile+"/file/pen2.csv";
			break;
		case 6:
			train_file=basefile+"/file/pen3.csv";
			break;
		case 7:
			train_file=basefile+"/file/pen-10.csv";
			break;
		case 8:
			train_file=basefile+"/file/pen-20.csv";
			break;
		case 9:
			train_file=basefile+"/file/pen-30.csv";
			break;
		case 10:
			train_file=basefile+"/file/pen-40.csv";
			break;
		case 11:
			train_file=basefile+"/file/pen-50.csv";
			break;
		case 12: 
			train_file=basefile+"/file/pen-60.csv";
			break;
		case 13: 
			train_file=basefile+"/file/wdbc-train.data";
			break;
		default: 
			System.out.println("Please input correct number");
			break;
			
		}
		
		System.out.println("If you want to prune,input 1, otherwith input 0");
		int IsPrune=sc.nextInt();
		System.out.println(IsPrune);
		if(IsPrune==1){
			if(input>0&&input<5){
				System.out.println("There is no test file and prune file");
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println(tree);
				
				
			}
			else if(input==5){
				test_file=basefile+"/file/pen-test2.csv";
				prune_file=basefile+"/file/pen-prune2.csv";
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println("--------Before Prune---------------");
				System.out.println(tree);
				TestTree test=new TestTree();
				DSet ftest=new DSet();
				ftest.readFile(test_file);
			    test=test.test(tree, ftest);
			    System.out.println(test);
			    System.out.println("---------After Prune---------------");
			    PruneTree prune=new PruneTree();
			    DSet fprune=new DSet();
			    fprune.readFile(prune_file);
			    DTree prTree=new DTree();
			    prTree=prune.prune(tree, fprune);
			    System.out.println(prTree);
			    TestTree newtest=new TestTree();
			    newtest=newtest.test(prTree, ftest);
			    System.out.println(newtest);
			}
			else if(input==6){
				test_file=basefile+"/file/pen-test3.csv";
				prune_file=basefile+"/file/pen-prune3.csv";
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println("--------Before Prune---------------");
				System.out.println(tree);
				TestTree test=new TestTree();
				DSet ftest=new DSet();
				ftest.readFile(test_file);
			    test=test.test(tree, ftest);
			    System.out.println(test);
			    System.out.println("---------After Prune---------------");
			    PruneTree prune=new PruneTree();
			    DSet fprune=new DSet();
			    fprune.readFile(prune_file);
			    DTree prTree=new DTree();
			    prTree=prune.prune(tree, fprune);
			    System.out.println(prTree);
			    TestTree newtest=new TestTree();
			    newtest=newtest.test(prTree, ftest);
			    System.out.println(newtest);
			}
			else if(input>=7&&input<=12){
				test_file=basefile+"/file/pen-test.csv";
				prune_file=basefile+"/file/pen-prune.csv";
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println("--------Before Prune---------------");
				System.out.println(tree);
				TestTree test=new TestTree();
				DSet ftest=new DSet();
				ftest.readFile(test_file);
			    test=test.test(tree, ftest);
			    System.out.println(test);
			    System.out.println("---------After Prune---------------");
			    PruneTree prune=new PruneTree();
			    DSet fprune=new DSet();
			    fprune.readFile(prune_file);
			    DTree prTree=new DTree();
			    prTree=prune.prune(tree, fprune);
			    System.out.println(prTree);
			    TestTree newtest=new TestTree();
			    newtest=newtest.test(prTree, ftest);
			    System.out.println(newtest);
				
			}
			else if(input==13){
				test_file=basefile+"/file/wdbc-test.data";
				prune_file=basefile+"/file/wdbc-prune.data";
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println("--------Before Prune---------------");
				System.out.println(tree);
				TestTree test=new TestTree();
				DSet ftest=new DSet();
				ftest.readFile(test_file);
			    test=test.test(tree, ftest);
			    System.out.println(test);
			    System.out.println("---------After Prune---------------");
			    PruneTree prune=new PruneTree();
			    DSet fprune=new DSet();
			    fprune.readFile(prune_file);
			    DTree prTree=new DTree();
			    prTree=prune.prune(tree, fprune);
			    System.out.println(prTree);
			    TestTree newtest=new TestTree();
			    newtest=newtest.test(prTree, ftest);
			    System.out.println(newtest);
			}
		}
		else if(IsPrune==0){
			if(input>0&&input<5){
				System.out.println("There is no test file ");
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println(tree);
				
				
			}
			else if(input==5){
				test_file=basefile+"/file/pen-test2.csv";
				prune_file=basefile+"/file/pen-prune.csv";
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println("--------Before Prune---------------");
				System.out.println(tree);
				TestTree test=new TestTree();
				DSet ftest=new DSet();
				ftest.readFile(test_file);
			    test=test.test(tree, ftest);
			    System.out.println(test);
			}
			else if(input==6){
				test_file=basefile+"/file/pen-test3.csv";
				prune_file=basefile+"/file/pen-prune.csv";
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println("--------Before Prune---------------");
				System.out.println(tree);
				TestTree test=new TestTree();
				DSet ftest=new DSet();
				ftest.readFile(test_file);
			    test=test.test(tree, ftest);
			    System.out.println(test);
			}
			else if(input>=7&&input<=12){
				test_file=basefile+"/file/pen-test.csv";
				prune_file=basefile+"/file/pen-prune.csv";
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println("--------Before Prune---------------");
				System.out.println(tree);
				TestTree test=new TestTree();
				DSet ftest=new DSet();
				ftest.readFile(test_file);
			    test=test.test(tree, ftest);
			    System.out.println(test);
			  
				
			}
			else if(input==13){
				test_file=basefile+"/file/wdbc-test.data";
				prune_file=basefile+"/file/wdbc-prune.data";
				DSet train=new DSet();
				train.readFile(train_file);
				DTree tree=new DTree();
				tree=tree.genTree(train);
				System.out.println("--------Before Prune---------------");
				System.out.println(tree);
				TestTree test=new TestTree();
				DSet ftest=new DSet();
				ftest.readFile(test_file);
			    test=test.test(tree, ftest);
			    System.out.println(test);
			   
			}
		}
		else{
			System.out.println("Invalid input!");
		}

	}

}
