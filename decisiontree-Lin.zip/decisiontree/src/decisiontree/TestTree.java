package decisiontree;
import treeStructure.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import dataset.*;

public class TestTree {
	int TP;
	int FP;
	
	static double iniAccuracy;
	ArrayList<Record> exp=new ArrayList<Record>();
	public TestTree(ArrayList<Record> a){
		exp=a;
	}
    static double accuracy;
	public TestTree(){}
	public TestTree test(DTree tree, DSet test){
		int size=test.dataset.size();
		TestTree.iniAccuracy=this.getIniAccuracy(test);
		

		DTnode curNode=tree.getRoot();
		for(int i=0;i<size;i++){
			//System.out.println("begin a new element");
			DElement de=test.dataset.get(i);
			int curSplitName=curNode.getSplitName();
			double curSplitValue=curNode.getPoint();
			double curEleValue=de.getElement(curSplitName).GetValue();
			if(curNode.getHasClass()==false){
				if(curEleValue<=curSplitValue){
					curNode=curNode.getChild(-1);
					//System.out.println("left"+curNode.getAttrName());
					produceClass(curNode,de);
				}
				else{
					curNode=curNode.getChild(1);
					//System.out.println("right"+curNode.getAttrName());
					produceClass(curNode,de);
				}
			}
			else{
				//System.out.println("get the class value");
				double p=curNode.getClassValue();
				double q=de.getElement(de.getElement().length-1).GetClass();
				Record record=new Record(p,q);
				exp.add(record);
				
			}
			curNode=tree.getRoot();
		}
		
		TestTree tt=new TestTree(exp);
		TestTree.accuracy=this.computeAccuracy(exp)*100;
		//System.out.println(this.getAccuray());
		return tt;
	}
	
	public void produceClass(DTnode node, DElement de){
		int curSplitName=node.getSplitName();
		double curSplitValue=node.getPoint();
		double curEleValue=de.getElement(curSplitName).GetValue();
		if(node.getHasClass()==false){
			if(curEleValue<=curSplitValue){
				node=node.getChild(-1);
				//System.out.println("left"+node.getAttrName());
				produceClass(node,de);
			}
			else{
				node=node.getChild(1);
				//System.out.println("left"+node.getAttrName());
				produceClass(node,de);
			}
		}
		else{
			double p=node.getClassValue();
			double q=de.getElement(de.getElement().length-1).GetClass();
			Record record=new Record(p,q);
			exp.add(record);
			
		}
		
		
	}
	
	public double computeAccuracy(ArrayList<Record> record){
		double a;
		int count=0;
		int total=record.size();
		for(int i=0;i<record.size();i++){
			if(record.get(i).getAct()==record.get(i).getExp()){
				count++;
			}
		}
//		System.out.println("compute the accuracy");
//		System.out.println(count);
//		System.out.println(total);
		a=(double)count/total;
//		System.out.println(a);
		return a;
	}
	public double getAccuray(){
		return TestTree.accuracy;
	}
	
	private class Record{
		double exp;
		double act;
		public Record(double pp, double qq){
			this.exp=pp;
			this.act=qq;
		}
		public double getExp(){
			return exp;
		}
		public double getAct(){
			return act;
		}
	}
	public double getIniAccuracy(DSet data){
		int size=data.dataset.size();
		int length=data.dataset.get(0).getElement().length;
		Map<Double, Integer> k=new HashMap<Double, Integer>();
		for(int i=0;i<size;i++){
		double key=data.dataset.get(i).getElement(length-1).GetClass();
		//System.out.println(key);
		if(k.containsKey(key)){
			int value=(int) k.get(key)+1;
			k.put(key,value);
		}
		else{
			k.put(key, 1);
		}
		}
		int max=0;
		
		for(double key:k.keySet()){
			if(k.get(key)>max){
				max=k.get(key);
				}
		}
		return (double)max/size;
		
	}
	public double takeIniAcc(){
		return TestTree.iniAccuracy;
	}
	public String toString(){
		String res="";
		res+="Initial Accuracy:"+this.takeIniAcc()+"\n";
		res+="------------Test the Tree------------------\n";
//		for(int i=0;i<exp.size();i++){
//			res+="Expected Class: "+exp.get(i).getExp()+"    ";
//			res+="Actual Class: "+exp.get(i).getAct()+"\n";
//		}
		res+="------------Result of Test-----------------\n";
		res+="Accuracy: "+this.getAccuray()+"%\n";
		return res;
	}

}
