package decisiontree;



import dataset.DElement;
import dataset.DSet;

import treeStructure.DTnode;
import treeStructure.DTree;

public class PruneTree {
	DTnode root;
	DTree tree;
	public PruneTree(DTree tr){
		this.tree=tr;
	}
	public PruneTree(){}
	public DTree setPrne(DTree original,DSet pset){
		int size=pset.dataset.size();
		DTnode curNode=original.getRoot();
		for(int i=0;i<size;i++){
			//System.out.println("begin a new element");
			DElement de=pset.dataset.get(i);
			curNode.setSubset(de);
			int curSplitName=curNode.getSplitName();
			double curSplitValue=curNode.getPoint();
			double curEleValue=de.getElement(curSplitName).GetValue();
			if(curNode.getHasClass()==false){
				if(curEleValue<=curSplitValue){
					curNode=curNode.getChild(-1);
					//System.out.println("left"+curNode.getAttrName());
					produceClass(curNode,de);
				}
				else{
					curNode=curNode.getChild(1);
					//System.out.println("right"+curNode.getAttrName());
					produceClass(curNode,de);
				}
				
			}
			else{
				//System.out.println("add a prune element");
				
			}
			curNode=original.getRoot();
		}
		return original;
	}

	public void produceClass(DTnode node, DElement de){
		int curSplitName=node.getSplitName();
		double curSplitValue=node.getPoint();
		double curEleValue=de.getElement(curSplitName).GetValue();
		node.setSubset(de);
		if(node.getHasClass()==false){
			if(curEleValue<=curSplitValue){
				node=node.getChild(-1);
				//System.out.println("left"+node.getAttrName());
				produceClass(node,de);
			}
			else{
				node=node.getChild(1);
				//System.out.println("left"+node.getAttrName());
				produceClass(node,de);
			}
		}
		else{
			//System.out.println("add a prune element");
			
		}
		
		
	}			
	
	public DTree prune(DTree original,DSet pset){
		DTree ptree=this.setPrne(original, pset);
		System.out.println(ptree);
		DTnode curNode=ptree.getRoot();
		DTnode left=curNode.getChild(-1);
		DTnode right=curNode.getChild(1);
		
		
		if(!left.getHasClass()){
			pNode(left);
		}
		if(!right.getHasClass()){
			pNode(right);
		}
		if(left.getHasClass()&&right.getHasClass()){
			double newClass=curNode.getMaxClassValue();
			int leftSize=left.getSubset().size();
			int rightSize=right.getSubset().size();
			int leftLength=left.getSubset().get(0).getElement().length;
			int rightLength=right.getSubset().get(0).getElement().length;
			int count=0;
			for(int i=0;i<leftSize;i++){
				if(left.getSubset().get(i).getElement(leftLength-1).GetClass()==newClass){
					count++;
				}
			}
			for(int j=0;j<rightSize;j++){
				if(right.getSubset().get(j).getElement(rightLength-1).GetClass()==newClass){
					count++;
				}
			}
			double pCorrect=(double)count;
			double leftCorrect=comAccuracy(left);
			double rightCorrect=comAccuracy(right);
			double proCorrect=(leftSize)*leftCorrect+(rightSize)*rightCorrect;
			if(pCorrect>proCorrect){
				//System.out.println("prune a node");
				curNode.deleteLChild(left);
			    curNode.deleteLChild(right);
			    curNode.setHasClass(true);
			    curNode.setClassValue(newClass);
			    
			    }
		}
		int a=ptree.getTreeDepth(ptree.getRoot());
		System.out.println("the new prune tree depth is "+a);
		ptree.setDepth(a);
		ptree.getTreeNode(ptree.getRoot());
		ptree.returnC();
		System.out.println("the new prune tree node is "+ptree.returnC());
		return ptree;
	}
	

	public double comAccuracy(DTnode leaf){
		int size=leaf.getSubset().size();
		int count=0;
		int length=leaf.getSubset().get(0).getElement().length;
		for(int i=0;i<size;i++){
			if(leaf.getSubset().get(i).getElement(length-1).GetClass()==leaf.getClassValue()){
				count++;
			}
		}
		double accuracy=count/size;
		return accuracy;
		
	}
	public void pNode(DTnode node){
		DTnode curNode=node;
		DTnode left=curNode.getChild(-1);
		DTnode right=curNode.getChild(1);
		
		
		if(!left.getHasClass()){
			pNode(left);
		}
		if(!right.getHasClass()){
			pNode(right);
		}
		if(left.getHasClass()&&right.getHasClass()){
			double newClass=curNode.getMaxClassValue();
			int leftSize=left.getSubset().size();
			int rightSize=right.getSubset().size();
//			System.out.println(leftSize);
//			System.out.println(rightSize);
			if(leftSize!=0&&rightSize!=0){
				int leftLength=left.getSubset().get(0).getElement().length;
				int rightLength=right.getSubset().get(0).getElement().length;
				int count=0;
				for(int i=0;i<leftSize;i++){
					if(left.getSubset().get(i).getElement(leftLength-1).GetClass()==newClass){
						count++;
					}
				}
				for(int j=0;j<rightSize;j++){
					if(right.getSubset().get(j).getElement(rightLength-1).GetClass()==newClass){
						count++;
					}
				}
				double pCorrect=(double)count;
				double leftCorrect=comAccuracy(left);
				double rightCorrect=comAccuracy(right);
				double proCorrect=(leftSize)*leftCorrect+(rightSize)*rightCorrect;
				if(pCorrect>proCorrect){
					//System.out.println("prune a node");
					//System.out.println(curNode.getSubset().size());
					curNode.deleteLChild(left);
				    curNode.deleteLChild(right);
				    curNode.setHasClass(true);
				    curNode.setClassValue(newClass);
				    }
			}
			
		}
	}
	
	public String toString(){
		String result="";
		result+="------------Tree Structure------------------\n";
		result+=root.toString();
		result+="------------Tree Information----------------\n";
		
		return result;
		
	}

}
